import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
import { Sample, Approval } from 'components/pages';

import 'antd/dist/antd.css';

function App() {
  return (
    <BrowserRouter>
      <Route exact path="/" component={Sample} />
      <Route exact path="/approval" component={Approval} />
    </BrowserRouter>
  );
}

export default App;
