export { default as ApprovalView } from 'components/organisms/ApprovalView';
export { default as ApprovalRegist } from 'components/organisms/ApprovalRegist';
