import React from 'react';
import { Link } from 'react-router-dom';
import { Menu } from 'antd';

import './header.css';

const HeaderContent = () => {
  return (
    <>
      <div className="logo">e-Security</div>
      <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['sample']} style={{ lineHeight: '64px' }}>
        <Menu.Item key="sample">
          <Link to="/">Sample</Link>
        </Menu.Item>
        <Menu.Item key="approval">
          <Link to="/approval">결재컴포넌트</Link>
        </Menu.Item>
      </Menu>
    </>
  );
};

export default HeaderContent;
