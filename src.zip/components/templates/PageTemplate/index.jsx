import React from 'react';
import { Layout, Breadcrumb } from 'antd';

import HeaderContent from 'components/templates/HeaderContent';
import SiderContent from 'components/templates/SiderContent';
import FooterContent from 'components/templates/FooterContent';

const { Header, Sider, Content, Footer } = Layout;

const PageTemplate = (props) => {
  const { children, breadcrumbItem = '' } = props;

  return (
    <>
      <Layout style={{ height: '100%' }}>
        <Header className="header">
          <HeaderContent />
        </Header>
        <Layout>
          <Sider width={200} style={{ background: '#fff' }}>
            <SiderContent />
          </Sider>
          <Layout style={{ padding: '0 24px 24px' }}>
            <Breadcrumb style={{ margin: '16px 0' }}>
              <Breadcrumb.Item>Home</Breadcrumb.Item>
              <Breadcrumb.Item>{breadcrumbItem}</Breadcrumb.Item>
            </Breadcrumb>
            <Content
              style={{
                overflowY: 'auto',
                background: '#fff',
                padding: 24,
                margin: 0,
                minHeight: 280
              }}
            >
              {children}
            </Content>
            <Footer style={{ textAlign: 'center' }}>
              <FooterContent />
            </Footer>
          </Layout>
        </Layout>
      </Layout>
    </>
  );
};

export default PageTemplate;
