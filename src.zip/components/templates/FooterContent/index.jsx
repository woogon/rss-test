import React from 'react';

const FooterContent = () => {
  return <>SkHynix ©2020 Created by e-Security</>;
};

export default FooterContent;
