import React from 'react';

import PageTemplate from 'components/templates/PageTemplate';

import ApprovalView from 'components/organisms/ApprovalView';
import ApprovalRegist from 'components/organisms/ApprovalRegist';

const Sample = () => {
  const customRequestDept = [
    {
      empId: 2049952,
      empNm: '김정민',
      jwNm: 'TL',
      deptNm: '경영지원PI',
      first: true,
      fixed: true
    }
  ];

  const customConfirmDept = [
    {
      empId: 2222222,
      empNm: '홍길동',
      jwNm: '부사장',
      deptNm: 'SK하이닉스',
      first: true
    },
    {
      empId: 2345678,
      empNm: '이지훈',
      jwNm: '팀장',
      deptNm: '개발',
      fixed: true
    }
  ];

  return (
    <PageTemplate breadcrumbItem="결재컴포넌트">
      <ApprovalView docId={12345} />
      <ApprovalRegist
        menuId="P12345"
        empId={2049952}
        docId={12252}
        customRequestDept={customRequestDept}
        customConfirmDept={customConfirmDept}
        callback={(result) => console.log(result)}
      />
    </PageTemplate>
  );
};

export default Sample;
