import React from 'react';

import PageTemplate from 'components/templates/PageTemplate';

const Sample = () => {
  return <PageTemplate breadcrumbItem="sample">Sample</PageTemplate>;
};

export default Sample;
