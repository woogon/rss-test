import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
import { Sample, Approval, SampleEditTable } from 'components/pages';

import 'antd/dist/antd.css';

function App() {
  return (
    <BrowserRouter>
      <Route exact path="/" component={Sample} />
      <Route exact path="/approval" component={Approval} />
      <Route exact path="/editable" component={SampleEditTable} />
    </BrowserRouter>
  );
}

export default App;
