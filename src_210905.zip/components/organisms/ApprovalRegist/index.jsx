import React, { useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import { Card, Descriptions, Row, Col, Badge, Tag, Input, Checkbox } from 'antd';

const ApprovalRegist = (props) => {
  const { menuId = 0, empId = 0, docId = 0, customRequestDept = null, customConfirmDept = null, callback = () => {} } = props;

  /**
   * customRequestDept / customConfirmDept sample object
   * customConfirmDept = [
   *    {
   *       "empId": 2049952,
   *       "empNm": "김정민",
   *       "jwNm":  "TL",
   *       "deptNm": "경영지원PI",
   *       "first": true/false
   *       "fixed": true/false
   *    }
   * ]
   */

  const [requestDeptList, setRequestDeptList] = useState([]);
  const [confirmDeptList, setConfirmDeptList] = useState([]);

  const [selectedRequestDept, setSelectedRequestDept] = useState([]);
  const [selectedConfirmDept, setSelectedConfirmDept] = useState([]);
  const [cancelEtc, setCancelEtc] = useState('');

  const findRequestDept = useCallback((params) => {
    let result = [];

    try {
      axios
        // .get(`/approval/requestDept?menuId={params.menuId}&empId={params.empId}`)
        .get('https://jsonplaceholder.typicode.com/posts')
        .then(function (response) {
          // handle success
          const dummy = [];
          result = dummy;
        })
        .catch(function (error) {
          // handle error
          console.log(error);
        })
        .then(function () {
          // always executed

          // merge confirm dept info
          if (customRequestDept && customRequestDept instanceof Array) {
            const temp = result;

            customRequestDept.forEach((item) => {
              if (item.first) {
                temp.unshift(item);
              } else {
                temp.push(item);
              }
            });

            setRequestDeptList(temp);
          }
        });
    } catch (e) {
      console.log(e);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const findConfirmDept = useCallback((params) => {
    let result = [];

    try {
      axios
        // .get(`/approval/confirmDept?menuId={params.menuId}&empId={params.empId}`)
        .get('https://jsonplaceholder.typicode.com/posts')
        .then(function (response) {
          // handle success

          const dummy = [
            {
              empId: 2065520,
              empNm: '김정연',
              jwNm: 'PL',
              deptNm: '경영정보PI',
              sign: 0,
              order: 0,
              date: '',
              cancelEtc: ''
            },
            {
              empId: 1111111,
              empNm: '이석희',
              jwNm: '사장',
              deptNm: 'SK Hynix',
              sign: 0,
              order: 2,
              date: '',
              cancelEtc: ''
            }
          ];

          result = dummy;
        })
        .catch(function (error) {
          // handle error
          console.log(error);
        })
        .then(function () {
          // always executed

          // merge confirm dept info
          if (customConfirmDept && customConfirmDept instanceof Array) {
            const temp = result;

            customConfirmDept.forEach((item) => {
              if (item.first) {
                temp.unshift(item);
              } else {
                temp.push(item);
              }
            });

            setConfirmDeptList(temp);
          }
        });
    } catch (e) {
      console.log(e);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const findApproval = useCallback((params) => {
    try {
      axios
        // .get(`/approval?docId={params.docUd}`)
        .get('https://jsonplaceholder.typicode.com/posts')
        .then(function (response) {
          // handle success
          console.log('findApproval >>> ', response);

          const dummy = {
            requestDept: [
              {
                empId: 2049952,
                empNm: '김정민',
                jwNm: 'TL',
                deptNm: '경영정보PI',
                sign: 1,
                order: 0,
                date: '2021-08-22 13:56:01',
                cancelEtc: ''
              }
            ],
            confirmDept: [
              {
                empId: 2065520,
                empNm: '김정연',
                jwNm: 'PL',
                deptNm: '경영정보PI',
                sign: 0,
                order: 0,
                date: '',
                cancelEtc: ''
              },
              {
                empId: 1111111,
                empNm: '이석희',
                jwNm: '사장',
                deptNm: 'SK Hynix',
                sign: 0,
                order: 2,
                date: '',
                cancelEtc: ''
              }
            ],
            requestEmp: {
              empId: 2049952,
              empNm: '김정민',
              jwNm: 'TL',
              deptNm: '경영정보PI',
              date: '2021-08-22 13:56:01',
              cancelEtc: '상신합니다.'
            }
          };

          // 요청부서
          if (dummy.requestDept && dummy.requestDept instanceof Array) {
            setSelectedRequestDept(dummy.requestDept);
          }

          // 허가부서
          if (dummy.confirmDept && dummy.confirmDept instanceof Array) {
            setSelectedConfirmDept(dummy.confirmDept);
          }

          // 비고
          if (dummy.requestEmp && dummy.requestEmp instanceof Array) {
            setCancelEtc(dummy.requestEmp.cancelEtc);
          }
        })
        .catch(function (error) {
          // handle error
          console.log(error);
        });
    } catch (e) {
      console.log(e);
    }
  }, []);

  const handleDeselect = (type, empId) => {
    if (type === 'R') {
      const selectObj = selectedRequestDept.filter((item) => item.empId !== empId);
      setSelectedRequestDept(selectObj ? selectObj : {});
    } else {
      const selectObj = selectedConfirmDept.filter((item) => item.empId !== empId);
      setSelectedConfirmDept(selectObj ? selectObj : {});
    }
  };

  const handleSelect = (type, empIds) => {
    if (empIds) {
      if (type === 'R') {
        const selectObj = empIds.map((empId) => requestDeptList.find((item) => item.empId === empId));
        setSelectedRequestDept(selectObj ? selectObj : {});
      } else {
        const selectObj = empIds.map((empId) => confirmDeptList.find((item) => item.empId === empId));
        setSelectedConfirmDept(selectObj ? selectObj : {});
      }
    }
  };

  // find confirm dept
  useEffect(() => {
    if (menuId !== 0 && empId !== 0) {
      const param = {
        menuId: menuId,
        empId: empId
      };

      findRequestDept(param);
      findConfirmDept(param);
    }
  }, [empId, menuId, customRequestDept, customConfirmDept, findRequestDept, findConfirmDept]);

  // find ap_appr
  useEffect(() => {
    if (docId !== 0) {
      findApproval(docId);
    }
  }, [docId, findApproval]);

  // call callback function
  useEffect(() => {
    const result = {
      requestDeptData: selectedRequestDept.map((item, idx) => {
        const temp = requestDeptList.find((element) => element.empId === item);
        return { ...temp, order: idx };
      }),
      confirmDeptData: selectedConfirmDept.map((item, idx) => {
        const temp = confirmDeptList.find((element) => element.empId === item);
        return { ...temp, order: idx };
      }),
      cancelEtc
    };

    callback(result);
  });

  return (
    <>
      <Card bordered={false}>
        <Descriptions
          bordered
          title="결재상신"
          column={2}
          extra={
            <>
              <Badge status="default" />
              <Badge status="success" />
              <Badge status="error" />
            </>
          }
        >
          <Descriptions.Item label="요청부서">
            {selectedRequestDept &&
              selectedRequestDept.map((item, idx) => (
                <Tag key={`request${idx}`} closable onClose={() => handleDeselect('R', item.empId)}>
                  {item.deptNm} {item.empNm}
                  {item.jwNm}
                </Tag>
              ))}
          </Descriptions.Item>
          <Descriptions.Item label="허가부서">
            {selectedConfirmDept &&
              selectedConfirmDept.map((item, idx) => (
                <Tag key={`confirm${idx}`} closable onClose={() => handleDeselect('C', item.empId)}>
                  {item.deptNm} {item.empNm}
                  {item.jwNm}
                </Tag>
              ))}
          </Descriptions.Item>
          <Descriptions.Item label="비고" span={2}>
            <Input.TextArea allowClear autoSize onChange={(e) => setCancelEtc(e.target.value)} />
          </Descriptions.Item>
        </Descriptions>

        <Descriptions
          bordered
          column={2}
          extra={
            <>
              <Badge status="default" />
              <Badge status="success" />
              <Badge status="error" />
            </>
          }
        >
          <Descriptions.Item label="요청부서">
            <Checkbox.Group onChange={(e) => handleSelect('R', e)}>
              {requestDeptList &&
                requestDeptList.map((item, idx) => {
                  return (
                    <Row key={`request${idx}`}>
                      <Col span={24}>
                        <Checkbox value={item.empId}>
                          {item.deptNm} {item.empNm}
                          {item.jwNm}
                        </Checkbox>
                      </Col>
                    </Row>
                  );
                })}
            </Checkbox.Group>
          </Descriptions.Item>
          <Descriptions.Item label="허가부서">
            <Checkbox.Group onChange={(e) => handleSelect('C', e)}>
              {confirmDeptList &&
                confirmDeptList.map((item, idx) => {
                  return (
                    <Row key={`confirm${idx}`}>
                      <Col span={24}>
                        <Checkbox value={item.empId}>
                          {item.deptNm} {item.empNm}
                          {item.jwNm}
                        </Checkbox>
                      </Col>
                    </Row>
                  );
                })}
            </Checkbox.Group>
          </Descriptions.Item>
          <Descriptions.Item label="비고" span={2}>
            <Input.TextArea allowClear autoSize onChange={(e) => setCancelEtc(e.target.value)} />
          </Descriptions.Item>
        </Descriptions>
      </Card>
    </>
  );
};

ApprovalRegist.propTypes = {
  menuId: PropTypes.string.isRequired,
  empId: PropTypes.number.isRequired,
  docId: PropTypes.number,
  customRequestDept: PropTypes.arrayOf(
    PropTypes.shape({
      empId: PropTypes.number.isRequired,
      empNm: PropTypes.string,
      jwNm: PropTypes.string,
      deptNm: PropTypes.string,
      first: PropTypes.boolean,
      fixed: PropTypes.boolean
    })
  ),
  customConfirmDept: PropTypes.arrayOf(
    PropTypes.shape({
      empId: PropTypes.number.isRequired,
      empNm: PropTypes.string,
      jwNm: PropTypes.string,
      deptNm: PropTypes.string,
      first: PropTypes.boolean,
      fixed: PropTypes.boolean
    })
  ),
  callback: PropTypes.func
};

export default ApprovalRegist;
