import React, { useState, useEffect, forwardRef, useImperativeHandle } from 'react';
import { Spin } from 'antd';

const CustomTable = (props, ref) => {
  const { loading = false, columns = [], dataSource = [] } = props;

  const [dataList, setDataList] = useState([]);

  const getValue = (e, prevValue) => {
    let value = '';

    if (e.target) {
      switch (e.target.type) {
        case 'text':
          value = e.target.value;
          break;
        case 'button':
          value = prevValue;
          break;
        default:
          break;
      }
    }

    return value;
  };

  const handleBlur = (e, dataIndex, index) => {
    const newData = dataList.map((data, idx) => {
      if (index === idx) {
        const prevValue = data[dataIndex];
        if (dataIndex) data[dataIndex] = getValue(e, prevValue);
        return data;
      } else {
        return data;
      }
    });

    setDataList([...newData]);
  };

  const handleRender = (item, data, index) => {
    return item.render({ text: data[item.dataIndex], data, index });
  };

  const getColumn = (item, data, index) => {
    if (item.render) {
      const node = handleRender(item, data, index);

      return {
        ...node,
        props: {
          ...node.props,
          defaultValue: data[item.dataIndex],
          onBlur: (e) => handleBlur(e, item.dataIndex, index)
        }
      };
    }

    return <>{data[item.dataIndex]}</>;
  };

  const handleDeleteRow = (idx) => {
    setDataList([...dataList.filter((_, index) => index !== idx)]);
  };

  const handleAddRow = (obj, order) => {
    let tmp = [...dataList];
    if (order === 'last') tmp = [...dataList, { ...obj, isNew: true }];
    else tmp = [{ ...obj, isNew: true }, ...dataList];
    console.log('handleAddRow >>> ', tmp);

    setDataList(tmp);
  };

  useEffect(() => {
    setDataList((prev) => {
      return [...dataSource];
    });
  }, [dataSource]);

  useImperativeHandle(ref, () => ({
    getData: () => {
      return dataList;
    },
    deleteRow: handleDeleteRow,
    addRow: handleAddRow
  }));

  return (
    <Spin spinning={loading}>
      <table style={{ width: '100%', border: '1px solid #e5e5e5' }}>
        <colgroup>
          {columns.map(() => (
            <col width="auto" />
          ))}
        </colgroup>
        <thead>
          <tr>
            {columns.map((column) => (
              <th>{column.title}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {dataList.length > 0 ? (
            dataList.map((data, index) => (
              <tr key={`tr_${index}`}>
                {columns.map((column, idx) => (
                  <td key={`td_${idx}`}>{getColumn(column, data, index)}</td>
                ))}
              </tr>
            ))
          ) : (
            <tr>
              <td colspan={columns.length}>{loading ? '조회 중...' : '데이터가 존재하지 않습니다.'}</td>
            </tr>
          )}
        </tbody>
      </table>
    </Spin>
  );
};

export default forwardRef(CustomTable);
