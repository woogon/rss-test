import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Table } from 'antd';

const EditTable = (props) => {
  const { columns, dataSource } = props;

  useEffect(() => {
    console.log('dataSource >>> ', dataSource);
  }, [dataSource]);

  return <Table columns={columns} dataSource={dataSource} />;
};

EditTable.propTypes = {};

export default EditTable;
