import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import { Card, Descriptions } from 'antd';

const ApprovalView = (props) => {
  const { docId = 0 } = props;

  const [data, setData] = useState({});

  const find = (param) => {
    try {
      axios
        // .get(`/approval?docId={docId}`)
        .get('https://jsonplaceholder.typicode.com/posts')
        .then(function (response) {
          // handle success
          setData({
            requestDept: [
              {
                empId: 2049952,
                empNm: '김정민',
                jwNm: 'TL',
                deptNm: '경영정보PI',
                sign: 1,
                order: 0,
                date: '2021-08-22 13:56:01',
                cancelEtc: ''
              },
              {
                empId: 2067752,
                empNm: '임XX',
                jwNm: '기정',
                deptNm: '경영정보PI',
                sign: 2,
                order: 1,
                date: '2021-08-22 14:05:01',
                cancelEtc: '취소합니다.'
              }
            ],
            confirmDept: [
              {
                empId: 2049952,
                empNm: '김정연',
                jwNm: 'PL',
                deptNm: '경영정보PI',
                sign: 0,
                order: 0,
                date: '',
                cancelEtc: ''
              },
              {
                empId: 2067752,
                empNm: '이석희',
                jwNm: '사장',
                deptNm: 'SK Hynix',
                sign: 0,
                order: 2,
                date: '',
                cancelEtc: ''
              }
            ],
            requestEmp: {
              empId: 2049952,
              empNm: '김정민',
              jwNm: 'TL',
              deptNm: '경영정보PI',
              date: '2021-08-22 13:56:01'
            }
          });
        })
        .catch(function (error) {
          // handle error
          console.log(error);
        });
    } catch (e) {
      console.log(e);
    }
  };

  useEffect(() => {
    if (docId !== 0) {
      const param = {
        docId: docId
      };

      find(param);
    }
  }, [docId]);

  return (
    <Card bordered={false}>
      <Descriptions bordered title="결재조회" column={1} extra={`상태`}>
        <Descriptions.Item label="상신자">
          {data.requestEmp && (
            <>
              <p>
                {data.requestEmp.deptNm} {data.requestEmp.empNm} {data.requestEmp.jwNm}
              </p>
              <p>{data.requestEmp.date}</p>
            </>
          )}
        </Descriptions.Item>
        <Descriptions.Item label="요청부서">
          {data.requestDept &&
            data.requestDept.map((item, idx) => (
              <div key={`request${idx}`}>
                <p>
                  {item.deptNm} {item.empNm} {item.jwNm}
                </p>
                <p>{item.date}</p>
              </div>
            ))}
        </Descriptions.Item>
        <Descriptions.Item label="허가부서">
          {data.confirmDept &&
            data.confirmDept.map((item, idx) => (
              <div key={`confirm${idx}`}>
                <p>
                  {item.deptNm} {item.empNm} {item.jwNm}
                </p>
                <p>{item.date}</p>
              </div>
            ))}
        </Descriptions.Item>
      </Descriptions>
    </Card>
  );
};

ApprovalView.propTypes = {
  docId: PropTypes.number.isRequired
};

export default ApprovalView;
