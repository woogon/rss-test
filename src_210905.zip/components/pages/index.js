export { default as Sample } from 'components/pages/Sample';
export { default as Approval } from 'components/pages/Approval';
export { default as SampleEditTable } from 'components/pages/SampleEditTable';
