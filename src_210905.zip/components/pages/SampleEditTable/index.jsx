import React, { useState, useEffect, useRef } from 'react';
import { Tag, Space, Input, Button } from 'antd';

import PageTemplate from 'components/templates/PageTemplate';
// import EditTable from 'components/organisms/EditTable';
import CustomTable from 'components/organisms/CustomTable';

const SampleEditTable = () => {
  const tableRef = useRef(null);

  const [dataList, setDataList] = useState([]);

  const [loading, setLoading] = useState(false);

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      render: ({ text }) => {
        return <Input defaultValue={text} onKeyDown={(e) => e.keyCode === 13 && alert('Enter')} style={{ width: 150 }} />;
      }
    },
    {
      title: 'age',
      dataIndex: 'age',
      render: ({ text, index }) => {
        return <Button onClick={() => onChangeVal(index)}>Change Value: {text}</Button>;
      }
    },
    {
      title: 'Delete',
      render: ({ index }) => {
        return <Button onClick={() => handleDeleteRow(index)}>Delete</Button>;
      }
    }
  ];

  const handleDeleteRow = (index) => {
    // if (tableRef) tableRef.current.deleteRow(index);
    setDataList([...dataList.filter((_, idx) => index !== idx)]);
  };

  const onChangeVal = (index) => {
    const newData = dataList.map((data, idx) => {
      if (index === idx) {
        return {
          ...data,
          age: data.age + 1
        };
      } else return data;
    });

    setDataList([...newData]);
  };

  const onSearch = () => {
    setLoading(true);
    setDataList([]);

    setTimeout(() => {
      setDataList([
        {
          key: '1',
          name: 'John Brown',
          age: 32,
          address: 'New York No. 1 Lake Park',
          tags: ['nice', 'developer']
        },
        {
          key: '2',
          name: 'Jim Green',
          age: 42,
          address: 'London No. 1 Lake Park',
          tags: ['loser']
        },
        {
          key: '3',
          name: 'Joe Black',
          age: 32,
          address: 'Sidney No. 1 Lake Park',
          tags: ['cool', 'teacher']
        }
      ]);

      setLoading(false);
    }, [500]);

    /* setDataList([
      {
        key: '1',
        name: 'John Brown',
        age: 32,
        address: 'New York No. 1 Lake Park',
        tags: ['nice', 'developer']
      },
      {
        key: '2',
        name: 'Jim Green',
        age: 42,
        address: 'London No. 1 Lake Park',
        tags: ['loser']
      },
      {
        key: '3',
        name: 'Joe Black',
        age: 32,
        address: 'Sidney No. 1 Lake Park',
        tags: ['cool', 'teacher']
      }
    ]); */
  };

  const getData = () => {
    const result = tableRef.current.getData();
    console.log('getData result >>> ', result);
  };

  const handleAddRow = () => {
    const obj = {
      key: '',
      name: '',
      age: 0,
      address: '',
      tags: null
    };

    setDataList([obj, ...dataList]);
  };

  useEffect(() => {
    console.log('change dataList >>> ', dataList);
  }, [dataList]);

  return (
    <PageTemplate breadcrumbItem="입력테이블">
      <Button onClick={onSearch}>조회</Button> <Button onClick={getData}>결과</Button> <Button onClick={handleAddRow}>추가</Button>
      <CustomTable ref={tableRef} columns={columns} dataSource={dataList} loading={loading} />
    </PageTemplate>
  );
};

export default SampleEditTable;
