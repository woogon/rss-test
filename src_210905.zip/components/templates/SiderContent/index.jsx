import React from 'react';
import { Link } from 'react-router-dom';
import { Menu } from 'antd';

const { SubMenu } = Menu;

const SiderContent = () => {
  return (
    <>
      <Menu mode="inline" defaultSelectedKeys={['1']} defaultOpenKeys={['sub1']} style={{ height: '100%' }}>
        <SubMenu key="Sample" title={<span>Sample</span>}>
          <Menu.Item key="sub1">
            <Link to="/">Sample Page</Link>
          </Menu.Item>
          <Menu.Item key="sub2">
            <Link to="/approval">결재컴포넌트</Link>
          </Menu.Item>
          <Menu.Item key="sub3">
            <Link to="/editable">입력테이블</Link>
          </Menu.Item>
        </SubMenu>
      </Menu>
    </>
  );
};

export default SiderContent;
